import React from 'react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { 
  MessageCircle, 
  MoreVertical, 
  Edit3, 
  Trash2, 
  Eye, 
  CheckCircle2, 
  Calendar,
  GripVertical,
  ArrowRight,
  ChevronDown
} from 'lucide-react';
import { Order, OrderStage } from '../types/order';
import { formatNaira, formatDate, generateWhatsAppLink } from '../utils/helpers';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from './ui/dropdown-menu';

interface OrderCardProps {
  order: Order;
  onViewDetails: (order: Order) => void;
  onEdit: (order: Order) => void;
  onDelete: (order: Order) => void;
  onMoveStage: (orderId: string, newStage: OrderStage) => void;
  isDragOverlay?: boolean;
}

const STAGES: OrderStage[] = [
  'New Chats',
  'Awaiting Payment',
  'To Pack',
  'Shipped',
  'Done & Happy',
];

const NEXT_STAGE_MAP: Record<OrderStage, OrderStage | null> = {
  'New Chats': 'Awaiting Payment',
  'Awaiting Payment': 'To Pack',
  'To Pack': 'Shipped',
  'Shipped': 'Done & Happy',
  'Done & Happy': null,
};

export const OrderCard: React.FC<OrderCardProps> = ({
  order,
  onViewDetails,
  onEdit,
  onDelete,
  onMoveStage,
  isDragOverlay = false,
}) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: order.id,
    data: { order },
    disabled: isDragOverlay,
  });

  const style: React.CSSProperties = {
    transform: CSS.Translate.toString(transform),
    transition,
    opacity: isDragging ? 0.35 : 1,
  };

  const whatsappUrl = generateWhatsAppLink(
    order.whatsappContact || order.phoneNumber,
    order.customerName,
    order.productDescription
  );

  const nextStage = NEXT_STAGE_MAP[order.orderStage];

  // Brand-aligned payment status indicators
  const renderPaymentBadge = () => {
    switch (order.paymentStatus) {
      case 'Paid':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-spacemono font-bold tracking-wider uppercase bg-[#EAF1EC] text-[#2F6B4F] border border-[#2F6B4F] px-2 py-0.5 rounded-full shadow-[1px_1px_0_#2F6B4F]">
            <span className="text-[11px] leading-none">✓</span>
            <span>PAID</span>
          </span>
        );
      case 'Part Payment':
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-spacemono font-bold tracking-wider uppercase bg-[#F8E8DE] text-[#9C4A22] border border-[#9C4A22] px-2 py-0.5 rounded-full shadow-[1px_1px_0_#9C4A22]">
            <span className="text-[11px] leading-none">!</span>
            <span>PART PAID</span>
          </span>
        );
      case 'Awaiting Payment':
      default:
        return (
          <span className="inline-flex items-center gap-1 text-[10px] font-spacemono font-bold tracking-wider uppercase bg-[#F7EEDD] text-[#8A5A1E] border border-[#8A5A1E] px-2 py-0.5 rounded-full shadow-[1px_1px_0_#8A5A1E]">
            <span className="text-[10px] leading-none">◷</span>
            <span>PENDING</span>
          </span>
        );
    }
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`group relative bg-white rounded-[14px] border-2 border-[#9A3442] p-3 sm:p-3.5 shadow-[4px_4px_0_#9A3442] hover:-translate-x-0.5 hover:-translate-y-0.5 transition-all duration-150 ${
        isDragOverlay ? 'drag-overlay-card' : ''
      }`}
    >
      {/* Top Drag & Move Strip: Large, touch-friendly drag handle */}
      <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#E9DDD9]/70">
        {/* Drag Handle Bar */}
        <div
          {...attributes}
          {...listeners}
          className="flex-1 flex items-center gap-1.5 py-1 px-2 -ml-1 rounded-md bg-[#FDFAF5] hover:bg-[#FDF1EF] text-[#9A3442] cursor-grab active:cursor-grabbing touch-none border border-[#9A3442]/30 hover:border-[#9A3442] transition-colors select-none"
          title="Click and drag to move order to another column"
        >
          <GripVertical className="w-4 h-4 stroke-[2.5] text-[#9A3442] shrink-0" />
          <span className="text-[10px] font-spacemono font-bold uppercase tracking-wider text-[#9A3442]">
            Hold &amp; Drag
          </span>
        </div>

        {/* Radix Action Dropdown Menu */}
        <div className="shrink-0 ml-1.5">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                className="w-7 h-7 rounded-md hover:bg-[#FDF1EF] text-[#9A3442] flex items-center justify-center transition-colors cursor-pointer border border-transparent hover:border-[#9A3442]/40"
                aria-label="Order actions"
              >
                <MoreVertical className="w-4 h-4 stroke-[2.2]" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => onViewDetails(order)}>
                <Eye className="w-3.5 h-3.5 mr-2 text-[#9A3442]" />
                <span className="font-semibold">View Details</span>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onEdit(order)}>
                <Edit3 className="w-3.5 h-3.5 mr-2 text-[#9A3442]" />
                <span className="font-semibold">Edit Order</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => onDelete(order)}
                className="text-[#9A3442] focus:bg-[#FDF1EF] font-bold"
              >
                <Trash2 className="w-3.5 h-3.5 mr-2 text-[#9A3442]" />
                <span>Delete Order</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Customer Name Row */}
      <div className="flex items-start justify-between gap-1.5 mb-1.5">
        <button
          onClick={() => onViewDetails(order)}
          className="text-left font-fraunces font-bold text-sm sm:text-[15px] text-[#9A3442] hover:text-[#521722] truncate transition-colors cursor-pointer tracking-tight"
        >
          {order.customerName}
        </button>
      </div>

      {/* Product Description */}
      <p 
        onClick={() => onViewDetails(order)}
        className="font-instrumentsans text-xs text-[#2A1B1E] line-clamp-2 mb-2.5 cursor-pointer hover:text-[#9A3442] transition-colors leading-relaxed"
      >
        {order.productDescription}
      </p>

      {/* Size, Category, Quantity Metadata (.mz-tag style) */}
      <div className="flex items-center flex-wrap gap-1.5 text-[10px] font-spacemono font-bold uppercase tracking-wider mb-2.5">
        <span className="bg-[#FAF6F2] text-[#9A3442] px-2 py-0.5 rounded-full border border-[#9A3442]/60">
          {order.productCategory}
        </span>
        {order.size && (
          <span className="bg-[#FDF1EF] text-[#9A3442] px-2 py-0.5 rounded-full border border-[#9A3442]">
            Size: {order.size}
          </span>
        )}
        <span className="text-[#6B5A5D] bg-[#FDFAF5] px-2 py-0.5 rounded-full border border-[#E9DDD9]">
          Qty: {order.quantity}
        </span>
      </div>

      {/* Price & Balance Pill Grid */}
      <div className="flex items-center justify-between py-1.5 px-2.5 rounded-[10px] bg-[#FAF6F2] border border-[#E9DDD9] mb-2 font-spacemono text-xs">
        <div>
          <span className="text-[9px] text-[#6B5A5D] block uppercase tracking-wider">Total</span>
          <span className="font-bold text-[#822936] tabular-nums">
            {formatNaira(order.orderAmount)}
          </span>
        </div>

        {order.balanceDue > 0 ? (
          <div className="text-right">
            <span className="text-[9px] text-[#9C4A22] block uppercase tracking-wider">Balance</span>
            <span className="font-bold text-[#9C4A22] tabular-nums">
              {formatNaira(order.balanceDue)}
            </span>
          </div>
        ) : (
          <div className="text-right">
            <span className="text-[9px] text-[#2F6B4F] block uppercase tracking-wider">Settled</span>
            <span className="font-bold text-[#2F6B4F]">Full ✓</span>
          </div>
        )}
      </div>

      {/* Footer Meta: Payment Badge & WhatsApp Quick Link */}
      <div className="flex items-center justify-between pt-1 text-[11px]">
        <div>
          {renderPaymentBadge()}
        </div>

        {/* WhatsApp 1-click Contact Button */}
        {(order.whatsappContact || order.phoneNumber) && (
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="inline-flex items-center gap-1 text-[10px] font-spacemono font-bold uppercase tracking-wider text-[#9A3442] bg-[#FDF1EF] hover:bg-[#FBDDD8] px-2 py-0.5 rounded-full border border-[#9A3442] shadow-[1px_1px_0_#9A3442] transition-all hover:-translate-x-0.5 hover:-translate-y-0.5"
            title="Chat directly on WhatsApp"
          >
            <MessageCircle className="w-3 h-3 text-[#9A3442]" />
            <span>WhatsApp</span>
          </a>
        )}
      </div>

      {/* 🚀 QUICK 1-TAP STAGE PROGRESSION */}
      <div className="mt-2.5 pt-2 border-t-2 border-[#9A3442]/30 flex items-center gap-1.5">
        {nextStage ? (
          /* Direct Advance to Next Stage Button */
          <button
            onClick={() => onMoveStage(order.id, nextStage)}
            type="button"
            className="flex-1 inline-flex items-center justify-center gap-1.5 py-1.5 px-2.5 rounded-full bg-[#9A3442] hover:bg-[#822936] text-white text-[11px] font-instrumentsans font-bold tracking-tight shadow-[2px_2px_0_#3D0F17] transition-all cursor-pointer hover:-translate-x-0.5 hover:-translate-y-0.5 active:translate-x-0 active:translate-y-0"
            title={`Move order to ${nextStage}`}
          >
            <span>Move to {nextStage}</span>
            <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
          </button>
        ) : (
          /* Completed Stage Status */
          <div className="flex-1 py-1 px-2.5 bg-[#EAF1EC] rounded-full border border-[#2F6B4F] text-[10px] font-spacemono font-bold uppercase tracking-wider text-[#2F6B4F] flex items-center justify-center gap-1 shadow-[1px_1px_0_#2F6B4F]">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#2F6B4F]" />
            <span>DELIVERED &amp; HAPPY</span>
          </div>
        )}

        {/* Radix Jump-to-Any-Stage Dropdown */}
        <div className="shrink-0">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                className="w-7 h-7 rounded-full bg-[#FDFAF5] hover:bg-[#FDF1EF] border-2 border-[#9A3442] text-[#9A3442] flex items-center justify-center transition-all cursor-pointer shadow-[1px_1px_0_#9A3442]"
                title="Jump directly to any stage"
                aria-label="Change stage"
              >
                <ChevronDown className="w-3.5 h-3.5 stroke-[2.5]" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-44">
              <DropdownMenuLabel>Select Stage</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {STAGES.map((st) => (
                <DropdownMenuItem
                  key={st}
                  disabled={st === order.orderStage}
                  onClick={() => onMoveStage(order.id, st)}
                  className={`flex items-center justify-between ${
                    st === order.orderStage ? 'font-bold text-[#9A3442] bg-[#FDF1EF]' : ''
                  }`}
                >
                  <span>{st}</span>
                  {st === order.orderStage && <CheckCircle2 className="w-3.5 h-3.5 text-[#9A3442]" />}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
};
