import React, { useState, useEffect } from 'react';
import { MessageCircle, AlertCircle, Trash2 } from 'lucide-react';
import { Order, OrderStage, PaymentStatus, ProductCategory } from '../types/order';
import { formatNaira, getTodayString, generateWhatsAppLink } from '../utils/helpers';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from './ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

interface OrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (orderData: Partial<Order>) => void;
  onDelete?: (order: Order) => void;
  initialOrder?: Order | null;
  defaultStage?: OrderStage;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  initialOrder,
  defaultStage = 'New Chats',
}) => {
  const isEditing = Boolean(initialOrder);

  // Form states
  const [customerName, setCustomerName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [whatsappContact, setWhatsappContact] = useState('');
  const [productDescription, setProductDescription] = useState('');
  const [productCategory, setProductCategory] = useState<ProductCategory>("Women's Innerwear");
  const [size, setSize] = useState('');
  const [quantity, setQuantity] = useState<number>(1);
  const [orderAmount, setOrderAmount] = useState<number | ''>('');
  const [amountPaid, setAmountPaid] = useState<number | ''>(0);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('Awaiting Payment');
  const [orderStage, setOrderStage] = useState<OrderStage>(defaultStage);
  const [orderDate, setOrderDate] = useState(getTodayString());
  const [dispatchDate, setDispatchDate] = useState('');
  const [notes, setNotes] = useState('');

  // Validation errors
  const [errors, setErrors] = useState<{ customerName?: string; productDescription?: string; orderAmount?: string }>({});

  useEffect(() => {
    if (initialOrder) {
      setCustomerName(initialOrder.customerName || '');
      setPhoneNumber(initialOrder.phoneNumber || '');
      setWhatsappContact(initialOrder.whatsappContact || initialOrder.phoneNumber || '');
      setProductDescription(initialOrder.productDescription || '');
      setProductCategory(initialOrder.productCategory || "Women's Innerwear");
      setSize(initialOrder.size || '');
      setQuantity(initialOrder.quantity || 1);
      setOrderAmount(initialOrder.orderAmount ?? '');
      setAmountPaid(initialOrder.amountPaid ?? 0);
      setPaymentStatus(initialOrder.paymentStatus || 'Awaiting Payment');
      setOrderStage(initialOrder.orderStage || defaultStage);
      setOrderDate(initialOrder.orderDate || getTodayString());
      setDispatchDate(initialOrder.dispatchDate || '');
      setNotes(initialOrder.notes || '');
    } else {
      setCustomerName('');
      setPhoneNumber('');
      setWhatsappContact('');
      setProductDescription('');
      setProductCategory("Women's Innerwear");
      setSize('');
      setQuantity(1);
      setOrderAmount('');
      setAmountPaid(0);
      setPaymentStatus('Awaiting Payment');
      setOrderStage(defaultStage);
      setOrderDate(getTodayString());
      setDispatchDate('');
      setNotes('');
    }
    setErrors({});
  }, [initialOrder, defaultStage, isOpen]);

  // Derived balance calculation
  const numericOrderAmount = typeof orderAmount === 'number' ? orderAmount : 0;
  const numericAmountPaid = typeof amountPaid === 'number' ? amountPaid : 0;
  const balanceDue = Math.max(0, numericOrderAmount - numericAmountPaid);

  // Auto update payment status when amounts change if user hasn't explicitly set it differently
  const handleAmountPaidChange = (valStr: string) => {
    const val = valStr === '' ? '' : parseFloat(valStr);
    setAmountPaid(val);

    const paid = typeof val === 'number' ? val : 0;
    if (numericOrderAmount > 0) {
      if (paid >= numericOrderAmount) {
        setPaymentStatus('Paid');
      } else if (paid > 0) {
        setPaymentStatus('Part Payment');
      } else {
        setPaymentStatus('Awaiting Payment');
      }
    }
  };

  const handleOrderAmountChange = (valStr: string) => {
    const val = valStr === '' ? '' : parseFloat(valStr);
    setOrderAmount(val);

    const total = typeof val === 'number' ? val : 0;
    if (total > 0 && numericAmountPaid > 0) {
      if (numericAmountPaid >= total) {
        setPaymentStatus('Paid');
      } else {
        setPaymentStatus('Part Payment');
      }
    }
  };

  // Generate WhatsApp quick chat URL
  const quickWhatsAppUrl = (phoneNumber || whatsappContact) 
    ? generateWhatsAppLink(whatsappContact || phoneNumber, customerName, productDescription)
    : null;

  const validate = (): boolean => {
    const newErrors: { customerName?: string; productDescription?: string; orderAmount?: string } = {};

    if (!customerName.trim()) {
      newErrors.customerName = 'Customer name is required';
    }

    if (!productDescription.trim()) {
      newErrors.productDescription = 'Item description is required';
    }

    if (orderAmount === '' || isNaN(numericOrderAmount) || numericOrderAmount < 0) {
      newErrors.orderAmount = 'Valid order amount is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validate()) return;

    const finalOrderAmount = typeof orderAmount === 'number' ? orderAmount : 0;
    const finalAmountPaid = typeof amountPaid === 'number' ? amountPaid : 0;
    const finalBalanceDue = Math.max(0, finalOrderAmount - finalAmountPaid);

    onSave({
      customerName: customerName.trim(),
      phoneNumber: phoneNumber.trim(),
      whatsappContact: (whatsappContact || phoneNumber).trim(),
      productDescription: productDescription.trim(),
      productCategory,
      size: size.trim(),
      quantity: Math.max(1, quantity),
      orderAmount: finalOrderAmount,
      amountPaid: finalAmountPaid,
      balanceDue: finalBalanceDue,
      paymentStatus,
      orderStage,
      orderDate,
      dispatchDate: dispatchDate.trim() || undefined,
      notes: notes.trim() || undefined,
    });

    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-xl p-0 overflow-hidden max-h-[92vh] flex flex-col" showCloseButton={true}>
        {/* Header */}
        <DialogHeader className="px-5 py-4 pr-12">
          <div>
            <DialogTitle className="text-lg sm:text-xl">
              {isEditing ? 'Edit Customer Order' : 'Add New Customer Order'}
            </DialogTitle>
            <DialogDescription className="flex items-center gap-1.5 mt-0.5 text-[11px] font-spacemono font-bold uppercase tracking-wider text-[#9A3442]">
              <span className="w-1.5 h-1.5 bg-[#9A3442] rotate-45 shrink-0" />
              <span>Minatzee Enterprise · Comfort you can trust.</span>
            </DialogDescription>
          </div>
        </DialogHeader>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-5 sm:p-6 space-y-5 kanban-scroll font-instrumentsans">
          
          {/* SECTION 1: CUSTOMER DETAILS */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-spacemono font-bold text-xs text-[#9A3442] tracking-[0.14em] uppercase flex items-center gap-2">
                <span className="w-2 h-2 bg-[#9A3442] rotate-45 shrink-0" />
                Customer Details
              </h3>
              {quickWhatsAppUrl && (
                <a
                  href={quickWhatsAppUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-[10px] font-spacemono font-bold uppercase tracking-wider text-[#9A3442] bg-[#FDF1EF] hover:bg-[#FBDDD8] px-2.5 py-1 rounded-full border border-[#9A3442] shadow-[1px_1px_0_#9A3442] transition-all"
                >
                  <MessageCircle className="w-3 h-3 text-[#9A3442]" />
                  <span>WhatsApp</span>
                </a>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Customer Name */}
              <div className="sm:col-span-2">
                <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                  Customer Name <span className="text-[#9A3442]">*</span>
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => {
                    setCustomerName(e.target.value);
                    if (errors.customerName) setErrors({ ...errors, customerName: undefined });
                  }}
                  placeholder="e.g. Amina Bello"
                  className={`w-full px-3.5 py-2.5 rounded-[8px] border-2 text-xs sm:text-sm text-[#2A1B1E] placeholder:text-[#CFBFA9] outline-none transition-all ${
                    errors.customerName
                      ? 'border-[#9A3442] bg-[#FDF1EF]'
                      : 'border-[#D98A96] bg-white hover:border-[#B04756] focus:border-[#9A3442] focus:ring-3 focus:ring-[#FBDDD8]'
                  }`}
                />
                {errors.customerName && (
                  <p className="mt-1 text-xs text-[#9A3442] font-spacemono font-bold uppercase flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{errors.customerName}</span>
                  </p>
                )}
              </div>

              {/* Phone Number */}
              <div>
                <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  inputMode="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="e.g. 0803 123 4567"
                  className="w-full px-3.5 py-2.5 rounded-[8px] border-2 border-[#D98A96] bg-white hover:border-[#B04756] focus:border-[#9A3442] focus:ring-3 focus:ring-[#FBDDD8] text-xs sm:text-sm text-[#2A1B1E] placeholder:text-[#CFBFA9] outline-none transition-all"
                />
              </div>

              {/* WhatsApp Number */}
              <div>
                <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                  WhatsApp Contact
                </label>
                <input
                  type="tel"
                  inputMode="tel"
                  value={whatsappContact}
                  onChange={(e) => setWhatsappContact(e.target.value)}
                  placeholder="e.g. 0803 123 4567"
                  className="w-full px-3.5 py-2.5 rounded-[8px] border-2 border-[#D98A96] bg-white hover:border-[#B04756] focus:border-[#9A3442] focus:ring-3 focus:ring-[#FBDDD8] text-xs sm:text-sm text-[#2A1B1E] placeholder:text-[#CFBFA9] outline-none transition-all"
                />
              </div>
            </div>
          </div>

          {/* SECTION 2: ORDER & PRODUCT DETAILS */}
          <div className="space-y-3 pt-3 border-t-2 border-[#E9DDD9]">
            <h3 className="font-spacemono font-bold text-xs text-[#9A3442] tracking-[0.14em] uppercase flex items-center gap-2">
              <span className="w-2 h-2 bg-[#9A3442] rotate-45 shrink-0" />
              Order &amp; Product Details
            </h3>

            <div>
              <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                Product Description <span className="text-[#9A3442]">*</span>
              </label>
              <textarea
                rows={2}
                value={productDescription}
                onChange={(e) => {
                  setProductDescription(e.target.value);
                  if (errors.productDescription) setErrors({ ...errors, productDescription: undefined });
                }}
                placeholder="e.g. Seamless Contour Wireless Bra & Briefs Set (Nude Blush)"
                className={`w-full px-3.5 py-2.5 rounded-[8px] border-2 text-xs sm:text-sm text-[#2A1B1E] placeholder:text-[#CFBFA9] outline-none transition-all resize-none ${
                  errors.productDescription
                    ? 'border-[#9A3442] bg-[#FDF1EF]'
                    : 'border-[#D98A96] bg-white hover:border-[#B04756] focus:border-[#9A3442] focus:ring-3 focus:ring-[#FBDDD8]'
                }`}
              />
              {errors.productDescription && (
                <p className="mt-1 text-xs text-[#9A3442] font-spacemono font-bold uppercase flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{errors.productDescription}</span>
                </p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Product Category (Radix UI Select) */}
              <div>
                <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                  Category
                </label>
                <Select
                  value={productCategory}
                  onValueChange={(val) => setProductCategory(val as ProductCategory)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Women's Innerwear">Women&apos;s Innerwear</SelectItem>
                    <SelectItem value="Children's Innerwear">Children&apos;s Innerwear</SelectItem>
                    <SelectItem value="Accessories">Accessories</SelectItem>
                    <SelectItem value="Sleepwear">Sleepwear</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Size */}
              <div>
                <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                  Size
                </label>
                <input
                  type="text"
                  value={size}
                  onChange={(e) => setSize(e.target.value)}
                  placeholder="e.g. 36B, M, 6-8 Yrs"
                  className="w-full px-3 py-2.5 rounded-[8px] border-2 border-[#D98A96] bg-white hover:border-[#B04756] focus:border-[#9A3442] focus:ring-3 focus:ring-[#FBDDD8] text-xs font-instrumentsans text-[#2A1B1E] placeholder:text-[#CFBFA9] outline-none"
                />
              </div>

              {/* Quantity */}
              <div>
                <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                  Quantity
                </label>
                <input
                  type="number"
                  inputMode="numeric"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full px-3 py-2.5 rounded-[8px] border-2 border-[#D98A96] bg-white hover:border-[#B04756] focus:border-[#9A3442] focus:ring-3 focus:ring-[#FBDDD8] text-xs font-spacemono font-bold text-[#2A1B1E] outline-none"
                />
              </div>
            </div>

            {/* Order Amount */}
            <div>
              <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                Total Order Amount (₦) <span className="text-[#9A3442]">*</span>
              </label>
              <input
                type="number"
                inputMode="decimal"
                min="0"
                step="100"
                value={orderAmount}
                onChange={(e) => {
                  handleOrderAmountChange(e.target.value);
                  if (errors.orderAmount) setErrors({ ...errors, orderAmount: undefined });
                }}
                placeholder="e.g. 15500"
                className={`w-full px-3.5 py-2.5 rounded-[8px] border-2 text-xs sm:text-sm font-spacemono font-bold text-[#2A1B1E] placeholder:text-[#CFBFA9] outline-none transition-all ${
                  errors.orderAmount
                    ? 'border-[#9A3442] bg-[#FDF1EF]'
                    : 'border-[#D98A96] bg-white hover:border-[#B04756] focus:border-[#9A3442] focus:ring-3 focus:ring-[#FBDDD8]'
                }`}
              />
              {errors.orderAmount && (
                <p className="mt-1 text-xs text-[#9A3442] font-spacemono font-bold uppercase flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{errors.orderAmount}</span>
                </p>
              )}
            </div>
          </div>

          {/* SECTION 3: PAYMENT TRACKING */}
          <div className="space-y-3 pt-3 border-t-2 border-[#E9DDD9]">
            <h3 className="font-spacemono font-bold text-xs text-[#9A3442] tracking-[0.14em] uppercase flex items-center gap-2">
              <span className="w-2 h-2 bg-[#9A3442] rotate-45 shrink-0" />
              Payment Details
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Payment Status (Radix UI Select) */}
              <div>
                <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                  Payment Status
                </label>
                <Select
                  value={paymentStatus}
                  onValueChange={(val) => setPaymentStatus(val as PaymentStatus)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Awaiting Payment">Awaiting Payment</SelectItem>
                    <SelectItem value="Part Payment">Part Payment</SelectItem>
                    <SelectItem value="Paid">Paid</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Amount Paid */}
              <div>
                <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                  Amount Paid (₦)
                </label>
                <input
                  type="number"
                  inputMode="decimal"
                  min="0"
                  step="100"
                  value={amountPaid}
                  onChange={(e) => handleAmountPaidChange(e.target.value)}
                  placeholder="0"
                  className="w-full px-3.5 py-2.5 rounded-[8px] border-2 border-[#D98A96] bg-white hover:border-[#B04756] focus:border-[#9A3442] focus:ring-3 focus:ring-[#FBDDD8] text-xs sm:text-sm font-spacemono font-bold text-[#2A1B1E] outline-none"
                />
              </div>
            </div>

            {/* Balance Due Display Box (Radix Status Scale: Amber for outstanding, Grass for paid) */}
            <div className={`p-3.5 rounded-[14px] border-2 shadow-[2px_2px_0] flex items-center justify-between ${
              balanceDue > 0
                ? 'bg-[#F8E8DE] border-[#9C4A22] shadow-[#9C4A22] text-[#6E3212]'
                : 'bg-[#EAF1EC] border-[#2F6B4F] shadow-[#2F6B4F] text-[#20503A]'
            }`}>
              <div>
                <span className="text-[11px] font-spacemono font-bold uppercase tracking-wider block">
                  {balanceDue > 0 ? 'Balance Due' : 'Balance Settled'}
                </span>
                <span className="text-[11px] font-instrumentsans opacity-85">
                  {balanceDue > 0 ? 'Outstanding customer balance' : 'Order fully paid ✓'}
                </span>
              </div>
              <div className="font-spacemono font-bold text-base sm:text-lg tabular-nums">
                {formatNaira(balanceDue)}
              </div>
            </div>
          </div>

          {/* SECTION 4: ORDER TRACKING */}
          <div className="space-y-3 pt-3 border-t-2 border-[#E9DDD9]">
            <h3 className="font-spacemono font-bold text-xs text-[#9A3442] tracking-[0.14em] uppercase flex items-center gap-2">
              <span className="w-2 h-2 bg-[#9A3442] rotate-45 shrink-0" />
              Order Tracking &amp; Notes
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Order Stage (Radix UI Select) */}
              <div>
                <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                  Order Stage
                </label>
                <Select
                  value={orderStage}
                  onValueChange={(val) => setOrderStage(val as OrderStage)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Stage" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="New Chats">New Chats</SelectItem>
                    <SelectItem value="Awaiting Payment">Awaiting Payment</SelectItem>
                    <SelectItem value="To Pack">To Pack</SelectItem>
                    <SelectItem value="Shipped">Shipped</SelectItem>
                    <SelectItem value="Done & Happy">Done &amp; Happy</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Order Date */}
              <div>
                <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                  Order Date
                </label>
                <input
                  type="date"
                  value={orderDate}
                  onChange={(e) => setOrderDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-[8px] border-2 border-[#D98A96] bg-white hover:border-[#B04756] focus:border-[#9A3442] focus:ring-3 focus:ring-[#FBDDD8] text-xs font-spacemono text-[#2A1B1E] outline-none"
                />
              </div>

              {/* Dispatch Date */}
              <div>
                <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                  Dispatch Date
                </label>
                <input
                  type="date"
                  value={dispatchDate}
                  onChange={(e) => setDispatchDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-[8px] border-2 border-[#D98A96] bg-white hover:border-[#B04756] focus:border-[#9A3442] focus:ring-3 focus:ring-[#FBDDD8] text-xs font-spacemono text-[#2A1B1E] outline-none"
                />
              </div>
            </div>

            {/* Internal Notes */}
            <div>
              <label className="block text-[11px] font-spacemono font-bold uppercase tracking-[0.14em] text-[#6B5A5D] mb-1">
                Internal Delivery Notes &amp; Special Requests
              </label>
              <textarea
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Customer requested discreet gift wrapping. Deliver after 4:00 PM."
                className="w-full px-3.5 py-2.5 rounded-[8px] border-2 border-[#D98A96] bg-white hover:border-[#B04756] focus:border-[#9A3442] focus:ring-3 focus:ring-[#FBDDD8] text-xs text-[#2A1B1E] placeholder:text-[#CFBFA9] outline-none resize-none"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-4 border-t-2 border-[#9A3442] flex items-center justify-between gap-3">
            <div>
              {isEditing && onDelete && initialOrder && (
                <button
                  type="button"
                  onClick={() => {
                    onDelete(initialOrder);
                    onClose();
                  }}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full text-[#9A3442] hover:bg-[#FDF1EF] border-2 border-[#9A3442] text-xs font-spacemono font-bold uppercase tracking-wider transition-all cursor-pointer shadow-[2px_2px_0_#9A3442] hover:-translate-x-0.5 hover:-translate-y-0.5 active:translate-x-0 active:translate-y-0"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Delete Order</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              {/* Secondary button: Outline Pill */}
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-full bg-white hover:bg-[#FDF1EF] border-2 border-[#9A3442] text-[#9A3442] text-xs font-spacemono font-bold uppercase tracking-wider transition-all cursor-pointer shadow-[2px_2px_0_#9A3442] hover:-translate-x-0.5 hover:-translate-y-0.5 active:translate-x-0 active:translate-y-0"
              >
                Cancel
              </button>
              {/* Primary button: Solid Wine Pill */}
              <button
                type="submit"
                className="px-5 py-2.5 rounded-full bg-[#9A3442] hover:bg-[#822936] text-white text-xs sm:text-sm font-instrumentsans font-semibold transition-all shadow-[3px_3px_0_#9A3442] hover:-translate-x-0.5 hover:-translate-y-0.5 active:translate-x-0 active:translate-y-0 cursor-pointer border-2 border-[#9A3442]"
              >
                {isEditing ? 'Save Changes' : 'Create Order'}
              </button>
            </div>
          </div>

        </form>
      </DialogContent>
    </Dialog>
  );
};
